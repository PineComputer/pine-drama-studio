# Changelog

All notable changes to the Pine Computer TypeScript SDK (`@pinesandbox/computer`) are
documented here. The format follows [Keep a Changelog](https://keepachangelog.com/). The
current beta compatibility line is `0.3.x`; review release notes before adopting a new
minor version.

## [0.3.6] — 2026-11-12

### Changed

- The default idle timeout is 30 minutes (was five): a Computer started without `idleTimeoutSeconds`
  keeps running that long without use. Pass `idleTimeoutSeconds: 300` to keep the old window. A project whose
  maximum idle timeout is under 30 minutes refuses a start that names no timeout.
- `startComputer` waits while the Computer's current runtime is saving or stopping (a Stop under way)
  and starts once its compute is released; it no longer refuses a saving runtime with
  `SandboxRetainedError`. `recoverComputer` waits the same way. When the runtime leaves Saving or
  Stopping for a state Start can't replace, the wait ends with that state's `SandboxRetainedError`.
- `readyTimeoutMs` (default still 300 000) covers the whole Start: the wait for the current
  runtime's release, the create and the new runtime's start. The separate fixed 90-second release
  wait is gone. A Stop issued while the Computer is paused can stay in Saving for several minutes, so
  a Start right after it needs a larger `readyTimeoutMs`, or it gets `ReadyTimeoutError`.
- When that budget runs out during the release wait, Start and Recover throw `ReadyTimeoutError`
  (was a plain `PineError`, "the failed Computer's shutdown is unconfirmed"). `ReadyTimeoutError`
  extends `PineError`, so `instanceof PineError` still matches. A budget that runs out inside the
  new runtime's first status read is also `ReadyTimeoutError` (was `TimeoutError`).
- `recoverComputer` refuses a runtime that has no recorded failure, or whose capture hasn't
  resolved (`CaptureTimeout`), with `SandboxRetainedError` (was a plain `Error`); a runtime the
  server reported without a version is refused with `PineError`. Nothing is released either way.
- Start and Recover refuse invalid options before they read or release anything.
- `SandboxRetainedError`, `ReadyTimeoutError` and `SandboxFailedError` messages give the runtime's
  id, exact state and reason, for example `Start refused: Computer runtime rt-… hasn't been
  released (state failed, reason STOPPED_UNEXPECTEDLY); nothing was started; recover it with
  recoverComputer, or Stop it and then Start`.
- `startComputer` and `recoverComputer` now throw `ComputerAlreadyStartedError` (new, a `BindError`
  but not a `SandboxRetainedError`) when the current runtime is running, pending, allocated or
  resuming. Code that catches `SandboxRetainedError` for those states must also handle the new class.
- Start's refusal for a save_failed runtime, or a terminated one without `COMPUTE_RELEASED`, now
  names `recoverComputer` (or Stop and then Start).
- `computer.stop({ timeoutMs })` and `client.stopComputer(id, { timeoutMs })` with a zero
  wait, or one too short to send the Stop, now stop the Computer and resolve `false`
  without waiting for the shutdown (`true` when the runtime is already gone). Before, they
  could resolve `false` while the Computer kept running. `timeoutMs` limits only the wait
  for the shutdown, not sending the Stop, so a call with a very short wait can take longer
  than the wait.
- A Stop that can't be sent (a timeout or a connection error) now throws, whatever the
  wait; it used to resolve `false` once the wait had passed. `false` means the runtime did
  not stop within the wait, after the Stop was submitted or while the runtime was already
  shutting down.
- A call that needs a binding on a handle that has none (`stop`, `kill` or `delete` on this
  handle removed it, or the handle was never attached) throws `BindError`, `binding()` and the handle's sessions included; it threw a plain `PineError`.
  `BindError` is a `PineError` subclass, so a `catch` that tests for `PineError` still
  matches. The message says why the handle has no binding, for example
  `pinesandbox: Computer <id>: this handle has no binding (Stop was called on this handle)`
  or `(it was never attached)`.
- A handle from `adoptExisting` with an empty Computer token has no binding too: `status`,
  `pause`, `resume`, `sandboxDetails` and `setIdleTimeout` now throw the `BindError` too.
- A request whose connection could not be opened (refused, name not resolved, connect
  or TLS handshake timed out) is sent again, three attempts in all, whatever its
- A request whose connection could not be opened (refused, a temporary name-resolution
  failure, connect or TLS handshake timed out) is sent again, three attempts in all, whatever its
  operation: nothing reached Pine. A creating write such as `desktopToken` or
  `createSession` used to fail at once, and so did `exec`. After a fault on an open
  connection, only replay-safe requests are sent again, as before.
- A rejected certificate or a host that doesn't exist is not special-cased: it goes
  through the same three attempts as any other connect failure and raises
  `ConnectionError`.
- `agent.wait` that reads through a network fault until its timeout returns the turn as
  it last read it, still running, instead of throwing; it throws only when no read came
  back. Such an error means this process lost the network, not that the turn failed.
- A `ConnectionError`'s message includes the network error under a generic
  `fetch failed`, such as `connect ECONNREFUSED`.
- `startComputer` and `recoverComputer` read the Computer's binding and current runtime within
  what is left of `readyTimeoutMs`. When it runs out there they throw `ReadyTimeoutError` ("The
  Computer's current runtime wasn't read within 5 s; nothing was released or started") instead of
  `TimeoutError` after up to three 30-second attempts.
- A create that `readyTimeoutMs` cut off after it may have reached Pine is sent once more with the
  same `create_id`, and the runtime it names is deleted: Start throws `ReadyTimeoutError` for it
  instead of `TimeoutError`, and no runtime is left behind. If that resend fails, the
  `TimeoutError` stays. A create that answers after `readyTimeoutMs` ran out is never bound, even
  when its runtime already runs.

### Added

- `SandboxRetainedError.reason`, `ReadyTimeoutError.lastReason` and `waitedMs` (the time spent
  against the budget), and `SandboxFailedError.reason`.
- `ProblemType.computerStopped` names the Computer's `409 /errors/computer-stopped`, its answer to every call once a Stop has begun, whoever sent it. Test it with `error.is(ProblemType.computerStopped)`. It isn't retryable: follow the Stop in `computer.status()`, then start it.
- `TerminalReason.timeout`, `incomplete`, `storageExhausted` and `terminalMissing`, the four values the
  spec's `terminal_reason` already allowed that had no constant. `TerminalReason` is now generated
  from the API spec; the existing names and values are unchanged.
- `ClientOptions.requestTimeoutMs` (default 30 000) bounds a request with no deadline
  of its own; a turn `wait` read gets the time the Computer holds it on top. The
  connect timeout belongs to the `fetch` (Node's: 10 seconds); the README shows a fetch
  bound to an undici `Agent` that sets another.
- `ProblemType.staleTask` and `ProblemType.eventsUnavailable` name an agent read's `409 /errors/stale-task` (a read pinned with `expectedTaskId` found another task) and `503 /errors/events-unavailable` (retry with the same cursor), beside `taskNotFound` and `historyExpired`.
- `ProblemType.sessionNameTaken`, `noPendingRequest`, `turnNotFound`, `authorInFlight`, `secretInSkill` and `skillsUnavailable` name more of a Computer's answers: a taken session name, an agent action on a turn that isn't waiting for an answer or doesn't exist, and a skill that is already being written, holds a secret, or can't be used on this Computer.

### Deprecated

- `ControlPatch.idlePaused`. To give a person more time, set a later `idleDeadline` or
  `idleDeadlineInSeconds`; a paused hold doesn't keep the Computer running, so the Computer can
  stop while the person works. It is still sent.

### Fixed

- `agent.run` throws `RunUnconfirmedError` when a resend after a lost response gets
  any error, such as a `SandboxGoneError` because the Computer stopped. It used to
  throw that error alone, which read as a run that never started although the first
  send may have started the turn. The error is the `cause`; check for
  `RunUnconfirmedError` first.

## [0.3.5] — 2026-10-31

- Return saved deliverables in the existing result `artifacts` list with `root: artifact_store`, `computer_id` and `relative_path`. Use the existing artifact client to download them. Update result handling before enabling session artifact access; workdir entries keep their existing shape.

- Turn usage exposes optional `cost.additional_details` with customer-facing descriptions and amounts, including late settlements.

### Added

- Turn usage includes generic additional customer charges, with unknown amounts
  preserved. Late usage events carry cumulative totals for their original turn;
  provider measurements and audit details remain private.
- `client.artifacts(computerId)` reaches a Computer's artifacts: the files it keeps
  beyond its sessions, whether it is running or stopped. The handle gets one
  short-lived storage token from Pine, renews it before it lapses, and sends every file
  straight to and from storage, so no file bytes pass through Pine.
  - `list({ prefix, recursive, pageToken, pageSize })` returns one page: `files` (each
    with `path`, `size`, `updatedAt`, `contentType` and `note`), `folders` and
    `nextPageToken`.
  - `upload(path, source, { contentType, note, size })` saves bytes, a `Blob`, or a
    `ReadableStream` with its `size`, and returns the saved file. A local file is a
    `Blob` (`openAsBlob(path)` from `node:fs`, or `Bun.file(path)`); text is
    `new TextEncoder().encode(text)`. The content type defaults to the one the path's
    extension names in the table every Pine SDK shares, else `application/octet-stream`.
  - `download(path, destination)` writes a local file through a temporary file beside
    it and returns its size; `open(path)` returns the file as a `ReadableStream`.
  - `copy(fromComputerId, fromPath, path)` copies a file from another of the project's
    Computers, or within this one, inside storage.
  - `delete(path)` deletes one file.

  Uploads, downloads and copies continue after a dropped connection, and uploads and
  downloads after storage answers 408, 429 or a 5xx other than 501; a storage error is
  `retryable` for those answers only, as in every Pine SDK. `download` needs Node.js 22.3
  or later, or Bun. A missing file throws `ArtifactNotFoundError` with its
  `path`; a `delete` sent again after a dropped response, whose first attempt already
  removed the file, succeeds. A storage error's `operation` names the route, with
  `{object}` in place of the file's name.

  A path in a Computer's artifacts is 1 to 900 bytes of UTF-8, with no control
  character and no empty, `.` or `..` segment (so no leading, trailing or doubled `/`);
  anything else is allowed. Every artifact call, `artifactLink` included, checks its
  paths before sending anything and throws an `Error` for one that breaks the rule.
  While the Computer stores more than its limit, `upload` and `copy` throw
  `ArtifactStorageFullError` (`usedBytes`, `limitBytes`) without sending anything; once
  files are deleted, the same handle writes again.
- `computer.artifactLink(path, { expiresInSeconds })` returns a public link (`url`,
  `expiresAt`) to one of the Computer's artifacts. The running Computer serves it, so it
  stops working when the Computer stops. `expiresInSeconds`, when given, is a whole
  number from 60 to 2,592,000 (30 days); any other value throws before anything is sent.
- `computer.createSession({ artifactAccess })` chooses what the session's agent may do
  with the Computer's artifacts: `"read_only"` lets it list and read files,
  `"read_write"` also lets it save and remove files and make public links. The agent can
  use the artifacts only when you choose one of these; the default, `"none"`, gives it
  none. Your own access with the project key is unaffected. `session.artifactAccess`
  (and `session.info.artifactAccess`) reports the choice; a Computer on an older release
  reports `"none"`, and a handle from `adoptSession`, which doesn't know it,
  `undefined`.

### Changed

- A `412 BINDING_REVISION_CONFLICT` is read from the API's `current_revision`,
  falling back to the deprecated `current_binding_revision` from an older Portal.
  `ApiError.currentBindingRevision` is renamed `currentRevision` to match the API;
  `BindingRevisionConflictError.currentRevision` is unchanged.
- The Computer sandbox status's `reason` docs list the codes a status can carry, such as
  `STARTING`, `RESUME_FAILED` and `COMPUTER_CAPACITY_UNAVAILABLE`, and its `message` is
  described as product text. The codes come from the server, so they apply to every SDK
  version once Pine's servers are updated.
- `recoverComputer` also recognizes `CAPTURE_TIMEOUT`, the SNAKE_CASE spelling a later server will
  send for `CaptureTimeout`, and refuses to release a Computer sandbox whose Pause is still
  confirming its capture under either spelling. Nothing changes with current servers.
- With servers that use the public status vocabulary, `StopSaveError`'s message is product
  text and no longer says why saving failed; Pine's server logs keep that detail.

### Removed

- `computer.createSession` no longer takes `browser` or `blind`, and `delegateDesktop`
  no longer takes `browser`: every session has a browser window. Before, a session
  created without `browser: true` had only a shell. For a password or MFA code only a
  person knows, the person takes control of the session over the desktop; a password
  your application has goes in the task's secrets, which the agent reads from
  `$SESSION_SECRETS`. `session.info.blind` is gone with them. Older releases keep
  sending both, and Computers still honor them.

## [0.3.4] — 2026-10-21

### Added

- The package ships its Apache-2.0 `LICENSE`.
- `session.openFile(path)` streams a file in the session's working directory without
  buffering it, such as a file a turn's `result.artifacts` names (by its `relativePath`).

### Changed

- **Breaking:** the names for what a started Computer runs in say Sandbox, matching the
  API's `sandbox_id` and the Computer sandbox in the docs. The Runtime names are removed,
  with no aliases:

  | Before | Now |
  |---|---|
  | `computer.runtimeId` | `computer.sandboxId` |
  | `computer.runtimeDetails()`, `RuntimeDetails` (and its `runtimeId`) | `computer.sandboxDetails()`, `SandboxDetails` (`sandboxId`) |
  | `RuntimeLifetime` | `SandboxLifetime` |
  | `RuntimeGoneError` | `SandboxGoneError` |
  | `RuntimeFailedError` | `SandboxFailedError` |
  | `RuntimeRetainedError` | `SandboxRetainedError` |
  | `RuntimeUnusableError` | `SandboxUnusableError` |
  | `runtimeId` on `SandboxFailedError`, `SandboxRetainedError`, `ReadyTimeoutError`, `AttachAuthorizationCommittedError`, `Binding` and `AttachCredentialsRequest` | `sandboxId` |
  | `currentRuntimeId` on `ApiError` and `BindingRevisionConflictError` | `currentSandboxId` |
  | `client.adoptExisting({ runtimeId })` | `client.adoptExisting({ sandboxId })` |
  | `ProblemType.runtimeNotFound`, `ProblemType.runtimeNotReady` | `ProblemType.sandboxNotFound`, `ProblemType.sandboxNotReady` |

  `runtimeRevision` and `maxRuntimeAgeSeconds` keep the API's field names.
- A `Binding` serializes as schema 2, which names the sandbox id `sandbox_id`.
  Bindings saved as schema 1 (`runtime_id`) still load. Earlier SDKs can't read
  schema 2, so upgrade every process that reads bindings before any of them saves
  one.
- `delegateDesktop`, `takeControl` and `releaseControl` require the session's name.
  A Computer has no default session, so they no longer fall back to one called
  "main"; an empty name throws before any request.
- The README installs the package from npm and links to the Pine Computer console, and
  the package's homepage is the Pine Computer website.
- The artifact methods (`listArtifacts`, `readArtifact`, `openArtifact`, `zipArtifacts`
  and `uploadArtifact`) throw an `ApiError` with `problemType`
  `ProblemType.featureDisabled` (403) when the project doesn't have the `artifacts`
  feature. Read a turn's files with `readFile` or `openFile` instead.

### Removed

- **Breaking:** `orphanDownloads`, `claimOrphanDownload` and `discardOrphanDownload` are
  removed, with the API's `/downloads/orphans` routes. A browser
  download the Computer can't link to a session goes to no session and is deleted
  after an hour. To get a download back, ask for it in the goal: the agent copies
  it into the working directory and lists it in the turn's result.

### Fixed

- A `pause` or `resume` whose `timeoutMs` runs out throws `ReadyTimeoutError`. If the
  platform's timers fired before the SDK's clock reached the deadline, it threw a plain
  `TimeoutError`. A request with a deadline now ends by the clock that set it.

## [0.3.3] — 2026-10-17

### Changed

- `@pinesandbox/computer` is published on npm, so `npm install @pinesandbox/computer`
  (or `bun add`, `pnpm add`) installs it without the portal download.

## [0.3.2] — 2026-10-17

### Added

- `computer.stop`, `computer.pause`, `computer.resume` and `client.stopComputer` take
  `timeoutMs`, the wait the Ruby SDK calls `wait_timeout:` / `timeout:`. `stop` resolves
  `false` when it runs out, so a request handler with a short budget can report "not
  confirmed yet" instead of aborting. The budget bounds every request the wait makes,
  including retries. The defaults (390 s, six minutes) are unchanged.
- `agent.events({ frames: false })` leaves out `frame` events, the same option name as
  `agent.eventsPage` and the Ruby SDK. `skipFrames: true` still works and is deprecated.
- `ApiError.extensions` holds the problem's members beyond `type`, `title`, `status`,
  `detail` and `instance` (for example `field` or `handoff_id`), and `ApiError.code` the
  machine code of a `{code, message}` response, like the Ruby SDK's `problem_extensions` and `code`. Such a
  response's `message` (or `error`) is now the error's `detail`.
- `ProblemType` names the control and hand-off problems the Ruby SDK has classes for:
  `preconditionFailed`, `invalidTransition`, `actorTypeRequired`, `invalidField`,
  `emptyPatch`, `malformedJson`, `desktopBindFailed` and the `handoff…` types, for
  `error.is(ProblemType.handoffExpired)`.

### Changed

- The error classes nest as the Ruby SDK's do: `AttachAuthorizationCommittedError`,
  `RuntimeRetainedError` and `TokenRejectedError` are `BindError`s, and `StreamLostError` is a
  `ConnectionError`, so `instanceof BindError` catches a Start that failed on a wrong key. Their
  names, fields and messages are unchanged, and each is still a `PineError`.
- Aborting `agent.events`, `session.controlEvents` or `session.authorEvents` rejects the
  `for await` with the signal's reason, and `computer.alive` rejects instead of resolving
  `false`, and no event already received is delivered after the abort. Before, an aborted
  stream ended as if the server had closed it.
- `session.controlEvents()` skips event names the Computer API doesn't define (the four in
  `ControlEventType`), as its contract requires; the stream still resumes after them.

### Deprecated

- `ProblemType.terminalLost`: no Computer sends it. A lost terminal is a 409 `ApiError` whose
  `code` is `"terminal_lost"`; call `session.recreateTerminal()` and run the command again.

### Fixed

- A Portal refusal (registration, deletion, attach credentials, Computer lookup, locations,
  project policy, diagnostics) puts Portal's own explanation in the error message, as the
  Ruby SDK does, for example that a Computer id was deleted. Before, the message was a fixed
  phrase and the explanation was only in `cause`.
- The README no longer calls `isRetryable(error)` a sign that resending is safe (it is the
  server's judgment, never permission to repeat a mutation), names `StopSaveError`, and says
  how Ruby's status-class rescues map to `ApiError.status` for a Computer's errors.
- `computer.delegateDesktop()` creates the session when it is missing, as the Ruby SDK does;
  pass `create: false` to require an existing one. Before, it threw the 404 unless you passed
  `create: true`.
- No `ApiError` field (message, `detail`, `title`, `code`, `extensions`) repeats an
  `X-EXECD-ACCESS-TOKEN` value a server or proxy echoed into its error body.
- Aborting a call while it waits to retry after a connection failure rejects with the
  signal's reason at once. Before, it threw the earlier `ConnectionError` or `TimeoutError`.
- `agent.run` with a signal that is already aborted rejects with the signal's reason and
  sends nothing. Before, it threw `RunUnconfirmedError`, as if the run might have started.
- `client.recoverComputer` bounds every request of the failed runtime's release by its 90 s
  wait; when that runs out it throws `PineError` ("the old runtime's release is unconfirmed;
  no replacement was allocated") instead of the release request's `TimeoutError`.
- A `readyTimeoutMs` shorter than 30 s also bounds the request that allocates the runtime and
  its retries.
- `agent.wait` gives each read the 30 s request deadline on top of the time it asks the
  Computer to hold (up to 25 s), as the Ruby SDK does. Before, a long hold left 5 s for the
  network and could end in `TimeoutError` and another read.
- `session.readFile`, `readArtifact` and `zipArtifacts` keep downloading for as long as bytes
  keep arriving, and fail with `TimeoutError` only after 30 s without any, as the Ruby SDK
  does. Before, the whole download had to finish in 30 s, so a large file or zip failed.
- `session.exec` fails with `TimeoutError` when the Computer sends nothing (not even its
  keep-alive) for `timeoutMs` plus 5 s, or 60 s without `timeoutMs`, as the Ruby SDK does.
  Before, a stalled connection kept `exec` waiting forever. A long `timeoutMs` also gives the
  response that long to start, and a connection that breaks mid-command is a
  `ConnectionError` instead of the runtime's raw error. An error answer whose body stalls is
  reported after the same read deadline, and an abort while reading it rejects with the
  signal's reason.

## [0.3.1] — 2026-10-17

### Added

- The TypeScript server SDK for Pine Computers, with the same objects, verbs and
  behavior as the Go, Ruby and Python SDKs: create, start, stop, pause, resume, recover
  and delete Computers; sessions; Pine's agent by turn (`run`, `wait`, `answer`,
  `steer`, `cancel`, `events`, `eventsPage`); driving a session yourself (`exec`,
  tabs, `drive.observe` and pointer and keyboard actions); files and artifacts;
  control and hand-offs; skills (`learn`, `teach`, `refine` and their review);
  passkeys; diagnostics; and `delegateDesktop` for `@pinesandbox/computer-web`.
- Credentials and bindings read and write the JSON the other Pine server SDKs use, so
  a Computer created from one language can be started or reconnected from another.
  Binding revisions are `bigint` and serialize exactly.
- Runs on Node.js 22 or later (ESM and CommonJS), Bun, Cloudflare Workers and
  Electron's main process. A browser bundle that imports the package builds and then
  throws on load: the SDK holds project and Computer credentials.
