# Pine Computer TypeScript SDK

`@pinesandbox/computer` is the TypeScript server SDK for Pine Computers. Create and
start Computers, give Pine's agent a goal or drive a session yourself, run shell
commands, move files, and hand a browser-safe connection to your web app. Stop/Start
restores saved cookies, learned skills and localStorage. Pause/Resume retains live
tabs, sessions and memory when enabled for your project.

See the [integration guide](https://console.pinecomputer.io/docs/integration) for setup,
authentication and examples. This README covers the TypeScript API. The Go, Ruby and
Python SDKs have the same objects and verbs, and read and write the same stored
credentials.

## Install

```sh
npm install @pinesandbox/computer
```

`bun add` and `pnpm add` work the same way. Using it needs a project key (`pk_…`) from
the [Console](https://console.pinecomputer.io). Access is by approval:
[request access](https://pinecomputer.io/#access) if you don't have one yet. Each release
is also a tarball on the [TypeScript SDK page](https://console.pinecomputer.io/sdks/typescript),
for vendoring.

The current SDK is on the `0.3` compatibility line.

## Where it runs

It uses only web-standard APIs (`fetch`, streams, WebCrypto), ships ESM and CommonJS,
and has three small dependencies (the HPKE implementation).

| Runtime | Notes |
|---|---|
| Node.js 22 or later | ESM `import` or CommonJS `require` |
| Bun | ESM |
| Cloudflare Workers and other Workers-class runtimes | The `workerd` / `worker` / `edge-light` export conditions |
| Electron's main process, CLIs, desktop-app backends | Node.js; keep the SDK out of renderer processes |

It refuses to load in a browser: it holds the project key, Computer credentials and
session tokens. A browser bundle that imports it builds, then throws on load. Embed a
desktop in your web or desktop app with
[`@pinesandbox/computer-web`](https://console.pinecomputer.io/sdks/web) and a
[delegated connection](#show-the-desktop-in-your-app) from your backend.

## Create a Computer

A **Computer** is the identity and saved browser state you keep. A **session** is work
inside the running Computer.
[Terms](https://console.pinecomputer.io/docs/how-a-computer-works#terms) defines the
rest.

The examples use `store` for your application's encrypted database; it is not an SDK
object. Save credentials **before** Create, then save the returned binding.

```ts
import { Client, Credentials } from "@pinesandbox/computer";

const client = new Client({
  endpoint: process.env.PINE_SANDBOX_ENDPOINT!,
  apiKey: process.env.PINE_SANDBOX_API_KEY!,
});
// or Client.fromEnv(), which reads the same variables

const credentials = await Credentials.generate();
await store.saveCredentials(credentials.id, credentials.serialize());

const computer = await client.createComputer({ credentials });
await store.saveBinding(computer.id, computer.binding().serialize());

const session = await computer.createSession(); // Pine picks the name: save session.name
await session.createTab("https://example.com");
```

The two records have different lifetimes:

| Save | When | Used for |
|---|---|---|
| `credentials.serialize()` | Before Create; again when you change keys | Starting this Computer again and decrypting its saved state |
| `computer.binding().serialize()` | After each successful Create or Start | Reconnecting to the running Computer from any backend |

Both contain secrets. Keep them encrypted on your backend, never in a browser.
`String(credentials)` and `String(binding)` redact them; `serialize()` does not.
Binding revisions are `bigint`: a revision can exceed `Number.MAX_SAFE_INTEGER`, and
`serialize()` writes it exactly.

`client.createComputer({ ephemeral: true })` creates a Computer without saved state:
nothing is restored and Stop saves nothing.

## Reuse it from another backend

```ts
import { Binding, Credentials } from "@pinesandbox/computer";

const computer = client.reconnectComputer(
  Credentials.parse(await store.credentials(computerId)),
  Binding.parse(await store.binding(computerId)),
);
const state = await computer.status(); // "running", "paused", "resuming", …
```

Reconnect rebuilds a handle locally. It makes no request, creates nothing and does not
replay work. Its next call goes to the Computer sandbox the binding names, even if
another backend has since started the Computer again. Store the binding revision alongside
its JSON, and save a replacement only if its revision is newer: a delayed reply must
not overwrite a newer binding. Sessions belong to a binding and cannot be reused
after Start.

To continue a session, save its name and token (`session.token`) when you create it,
then call `computer.adoptSession(name, token)`. `computer.session(name)` and
`computer.sessions()` return session metadata without the token; such a handle can
read (files, agent turns and events) but not drive. Save agent turn IDs and
event cursors with the session so another worker can wait for existing work instead of
submitting it again.

## Stop, Start, Pause or Resume

| Intent | Call | Result |
|---|---|---|
| Finish using compute | `computer.stop()` | Attempts a final save, shuts the Computer down and ends its sessions |
| Start a stopped Computer | `client.startComputer(credentials)` | Runs the Computer from its saved state; create new sessions |
| Stop after losing the handle | `client.stopComputer(id)` | Stops whichever runtime the Computer's binding points to when called, which may be another worker's; recover one Computer at a time |
| Keep live memory for later | `computer.pause()` | Keeps the Computer and its sessions in memory; requires project opt-in |
| Continue paused work | `computer.resume()` | Brings back the paused Computer and its sessions |
| Recover a failed Computer | `client.recoverComputer(credentials)` | Shuts the failed Computer down, then starts it from saved state |
| Observe after a connection failure | `computer.status()` | Reads state without changing or renewing it |

```ts
if (!(await computer.stop())) throw new Error("Stop is unconfirmed; keep the binding and retry");

// Later, at a safe boundary chosen by your application:
const started = await client.startComputer(credentials);
await store.saveBinding(started.id, started.binding().serialize());
```

`stop()` waits up to 390 s for the Computer to shut down (`timeoutMs` sets another
budget; `pause()` and `resume()` take it too, default six minutes). Saving is best effort: a
save that fails still shuts the Computer down, `stop()` resolves `true`, and the next
Start restores the last saved state. Only an older server keeps the Computer running
after a failed save and throws `StopSaveError`. `false` means completion is unconfirmed.

While the Computer's runtime is saving or stopping (a Stop under way), Start waits for
its release, then starts. Start refuses any other runtime that hasn't been released and
starts nothing: one already started (running, or on its way there) with
`ComputerAlreadyStartedError`, any other, such as a paused or failed one, with
`SandboxRetainedError`. Their `state` and `reason` are what the runtime reported. A failed runtime comes back
with `recoverComputer`, or by stopping it and then starting; with the reason
`CaptureTimeout` (`CAPTURE_TIMEOUT` on later servers) `recoverComputer` refuses
until the capture settles.
[When Start waits or refuses](https://console.pinecomputer.io/docs/integration#when-start-waits-or-refuses)
covers every state. `recoverComputer`
accepts the loss of unsaved state, shuts down only a Computer that has failed, and never
replaces a healthy one. Do not rescue a failed `resume()` with `startComputer`:
retrying Resume keeps the memory; Start gives up on it.

`computer.kill()` shuts the Computer down without a save. `computer.delete()` (or
`client.deleteComputer(id)`) is **permanent**: it kills the running Computer and
deletes the identity and its saved state.

## Idle timeout and maximum age

`idleTimeoutSeconds` (default 1800, at least 60) is how long a Computer keeps
running without use. Work renews it; reading status, watching events and other
observation do not. `readyTimeoutMs` (default 300 000) bounds the whole Start: waiting
for the current runtime's release, the create and the new runtime's start. When it runs
out, `ReadyTimeoutError` names the runtime it waited on (`sandboxId`), its `lastState` and
`lastReason` (for example `COMPUTER_CAPACITY_UNAVAILABLE`) and `waitedMs`; nothing was
attached. `bindReadyTimeoutMs` bounds the attach handshake after it.

When the agent asks a question, nothing happens on the Computer until the answer
arrives, so the countdown keeps running. Choose a timeout longer than a person
may take to reply, or raise it with `setIdleTimeout` when the question arrives.
A Computer that stops this way saves its state once without confirming it; call
`stop()` yourself when the state matters.

```ts
const computer = await client.startComputer(credentials, { idleTimeoutSeconds: 3600 });

const details = await computer.sandboxDetails();
if (details.lifetime) {
  const updated = await computer.setIdleTimeout(7200);
  console.log(updated.lifetime?.idleTimeoutSeconds, updated.expiresAt);
}
```

`details.lifetime` is present when the Computer was started under your project's
lifetime policy; `client.projectPolicy()` reads the allowances for future starts. A
changed idle timeout applies now while running, or at the next Resume while paused.
It never extends maximum age, which includes paused time.

## Sessions

A session is a browser window and a shell. A Computer runs up to three sessions at
once by default; `computer.capabilities()` reports the limit.

```ts
const s = await computer.createSession({ name: "researcher-1" });
await computer.sessions(); // every session, without tokens
await computer.destroySession("researcher-1", { clean: true });
```

A session's agent can use the Computer's [artifacts](#artifacts) only when you create
the session with `artifactAccess: "read_only"` (list and read them) or `"read_write"`
(also save, remove and link them); the default, `"none"`, gives it none.
`session.artifactAccess` reports the choice, or `undefined` on a handle from
`adoptSession`, which doesn't know it.

## Pine's agent

`session.agent` gives Pine's agent a **goal**. Work is addressed by **turn**: a turn
starts when a run or an answer is accepted and ends when the agent finishes, fails, is
canceled or asks a question. Every ending is the turn's `result`, with its `usage`. A
question is the result's summary (`turn.question`); the answer starts the next turn,
which continues the same goal. A session has one agent whose memory persists across
runs; `agent.reset(taskId)` starts fresh.

```ts
const agent = session.agent;
// savedMessageId is your durable request identity. A run with the same key returns
// the turn it admitted, so a lost response never starts a second run.
let turn = await agent.run("Find the cheapest direct SFO→NRT flight next month", {
  idempotencyKey: savedMessageId,
});
await record.update({ turnId: turn.turnId });

// Any worker, later:
turn = await agent.wait(record.turnId, { timeoutMs: 30_000 });
switch (turn.state) {
  case "running":
  case "canceling":
    scheduleAnotherWait(record);
    break;
  case "needs_input":
    presentQuestion(record, turn.turnId, turn.question);
    break;
  case "answered": // another worker answered
    await record.update({ turnId: turn.nextTurnId });
    break;
  default: // completed, failed or canceled
    saveOutcome(record, turn.state, turn.result);
}

// The process that receives the reply answers the turn that asked:
turn = await agent.answer(reply.turnId, "Use the card ending 4242");
```

- `wait` holds while the turn runs and returns it when it ends or `timeoutMs` passes
  (still `running`). It never cancels the turn or follows `nextTurnId`. A read lost to
  the network is read again until the timeout; then `wait` returns the turn as it last
  read it, or throws the last error when no read came back (see
  [Slow or interrupted networks](#slow-or-interrupted-networks)).
- `run`, `answer` and `cancel` resend a lost response for about 30 seconds, honoring
  `Retry-After`. A lost response is a network fault, a 408, or a gateway 502, 503 or
  504. If none arrives, `run` throws `RunUnconfirmedError` with the `idempotencyKey`
  to send again. After a lost response, a resend's error, a `SandboxGoneError`
  included, is thrown as `RunUnconfirmedError` too, with that error as `cause`: check
  for `RunUnconfirmedError` first.
- Only the latest turn can be answered. The same answer again returns the same new
  turn; a different one throws a 409 (`/errors/stale-turn`).
- `agent.steer(turnId, text)` adds guidance while that turn runs. It is never resent.
- `agent.cancel(turnId)` cancels a running turn or closes its waiting question; any
  other ended turn comes back unchanged, so retrying is safe.
- `agent.status()` returns the session's task and its latest turn; `agent.turns()` the
  retained turns, oldest first.
- Put credentials in `secrets` (`run`, `answer`, `steer`) and refer to them as `$NAME`
  in text: they never enter the model's context.

`computer.requireAgentProtocol()` checks that the Computer serves this agent protocol;
a Computer started on an older release throws `AgentProtocolUnsupportedError` (Stop, then Start,
updates it).

### Activity

`agent.events()` streams what the agent does. Use it to show progress, not to detect
how a turn ended: `wait` does that. The stream reconnects by itself and resumes from
its last event.

```ts
const { taskId } = await agent.status();
for await (const event of agent.events({ lastEventId: savedCursor, expectedTaskId: taskId })) {
  const step = event.activity(); // one row per step: upsert by step.id
  if (step) upsertStep(step.id, step.state, step.title);
  const progress = event.progress(); // the agent explains what it is doing
  if (progress) narrate(progress.text);
  const frame = event.frame(); // the screen, as WebP
  if (frame) showScreen(frame.data, frame.activity?.id);
  await saveCursor(taskId, event.eventId);
}
```

A saved cursor is valid only for the task it was stored with. `agent.eventsPage({ after,
limit })` reads the same events as pages. Activity carries a step's kind, an imperative
title ("Click “Log in”") and typed facts; it never carries tool arguments, command
output or anything typed into a page.

## Drive it yourself

```ts
const { stdout, exitCode } = await session.exec("python3 build_report.py", { timeoutMs: 120_000 });

const drive = session.drive;
for (;;) {
  const screen = await drive.observe(); // screenshot plus the coordinate metadata
  const action = await myPolicy.next(screen);
  if (action.done) break;
  await drive.click(action.x, action.y); // typeText, key, scroll, …, or drive.computerUse(kind, params)
}
```

`observe` is read-only and allowed while Pine's agent runs. Acting takes the drive
slot: a 409 means Pine's agent or a person holds it. `listTabs`, `createTab`,
`patchTab`, `closeTab` and `focus` cover tabs and the window.

## Files

```ts
await session.listFiles({ pattern: "*.csv" });
const report = await session.readFile("out/report.csv"); // the work directory, as bytes
const body = await session.openFile("out/export.zip"); // a ReadableStream, never buffered
await session.writeFile("brief.md", brief); // lands in attachments/, which the agent reads

// The files an ended turn produced, by their path in the work directory:
for (const file of turn.result?.artifacts ?? []) {
  await save(file.relativePath, await session.readFile(file.relativePath));
}
```

Read a turn's files when it ends: they stay in the work directory, where a later turn
or command can change them. A browser download isn't one of them; to get one back, ask
for it in the goal, and the agent copies it into the work directory and lists it.
Session files last until the Computer stops; save what you need first.

## Artifacts

A Computer's artifacts are the files it keeps beyond its sessions. Reach them with the
project key, whether the Computer is running or stopped:

```ts
const artifacts = client.artifacts(computerId); // keep it: it reuses its storage token
const page = await artifacts.list({ prefix: "research/" }); // files, folders, nextPageToken
await artifacts.upload("inputs/brief.md", await openAsBlob("./brief.md"), { note: "the brief" }); // bytes, a Blob or a stream with { size }
await artifacts.download("research/q3.csv", "./q3.csv"); // returns the byte count
const body = await artifacts.open("reports/q3.pdf"); // a ReadableStream
await artifacts.copy(otherComputerId, "reports/q3.pdf", "inputs/q3.pdf"); // or this Computer's id
await artifacts.delete("inputs/brief.md");

const { url } = await computer.artifactLink("reports/q3.pdf", { expiresInSeconds: 86_400 });

// Let a session's agent read them too:
const research = await computer.createSession({ name: "research", artifactAccess: "read_only" });
```

The handle gets one short-lived storage token from Pine and sends every file straight to
and from storage. Uploads, downloads and copies continue after a dropped connection, and
`download` writes through a temporary file, so the destination is never left half
written. A local file to upload is a `Blob`: `openAsBlob(path)` from `node:fs`, or
`Bun.file(path)`; text is `new TextEncoder().encode(text)`. `download` needs Node.js 22.3
or later, or Bun; in a Worker, read with `open`. A missing file is
`ArtifactNotFoundError`. While a Computer stores more than its limit, `upload` and
`copy` throw `ArtifactStorageFullError`; once files are deleted, the same handle writes
again. A link from
`artifactLink` is served by the running Computer: anyone with it can download the file
until it expires (`expiresInSeconds`, 60 to 2,592,000) or the Computer stops.

A session's agent can use the artifacts only when you create the session with
`artifactAccess: "read_only"` or `"read_write"`. Your own access with the project key,
above, is unaffected.

## Control

A person and an agent share a session's screen; control decides who acts.

```ts
await session.takeControl(); // the person drives; Pine's agent waits
await session.releaseControl();
await session.notifyHuman("Please sign in to continue");
for await (const change of session.controlEvents()) updateBanner(change);
```

## Show the desktop in your app

Your backend hands the browser a `DelegatedConnection`. It holds a desktop token that
expires after two minutes, never a project key, Computer token or session token.

```ts
// In your backend route, for a signed-in user:
const connection = await computer.delegateDesktop(savedSessionName);
return Response.json(connection, { headers: { "Cache-Control": "no-store" } });
```

The browser passes it to `<pine-desktop>` from `@pinesandbox/computer-web`.

## Skills

`session.learn()` drafts a skill from the agent's last finished turn;
`session.teach(goal)` drafts one from a demonstration a person just finished and
released; `session.refine(skill, version, guidance)` revises one. Each runs a
separate authoring model, typically for 30 to 180 seconds, and resolves with its
outcome. Behind a proxy with a short request timeout, use `startLearn`, `startTeach`
or `startRefine` instead, and follow `session.authorEvents(run.authorId)`.

Drafts wait for review: `computer.skills.drafts()`, then
`computer.skills.activate(name, version)`. Nothing learned reaches another agent until
you activate it.

## Errors

[Troubleshooting](https://console.pinecomputer.io/docs/troubleshooting) says what
each common error means and how to fix it.

Every error extends `PineError`. HTTP failures are `ApiError` with `status`,
`problemType`, `code`, `extensions`, `host`, `operation` and `requestId`;
`error.is(ProblemType.staleTurn)` tests the problem type. Once a Stop has begun, whoever
sent it, every call rejects with an `ApiError` for which `error.is(ProblemType.computerStopped)`
holds: follow the Stop in `computer.status()`, then start it. A Computer's errors are all
`ApiError`: where Ruby rescues `NotFoundError` or `ConflictError` for a missing session or a
busy one, test `error.status` (or `error.is(…)`). The status-named classes below are for the
lifecycle API only. The specific ones:

| Error | Means |
|---|---|
| `SandboxGoneError` | The Computer can't be reached; check `computer.status()` before starting again |
| `TokenRejectedError` | The Computer token was not accepted |
| `AgentProtocolUnsupportedError` | The Computer was started before the public agent protocol |
| `RunUnconfirmedError` | No response confirmed the run; send it again with `idempotencyKey` |
| `StreamLostError` | An event stream could not reconnect; resume from your cursor |
| `ComputerAlreadyStartedError` | Start or Recover found the Computer already started (`state`, `reason`); reconnect with the saved binding, or stop it first; nothing was started |
| `SandboxRetainedError` | Start or Recover found a runtime it may not replace (`state`, `reason`); nothing was started |
| `ReadyTimeoutError` | Start, `pause()` or `resume()` ran out of its budget (`lastState`, `lastReason`, `waitedMs`); nothing was attached |
| `SandboxFailedError` | The runtime reported failed, unavailable or terminated before it ran (`state`, `reason`) |
| `StopSaveError` | An older server could not save on Stop and kept the Computer running; `retryable` says whether to try again |
| `AttachAuthorizationCommittedError` | Create registered the Computer but did not finish; keep `credentials` |
| `BindingRevisionConflictError` | Another Start won; reload its binding instead of retrying |
| `BindError` and subclasses | The attach handshake failed. A `BindError` from a call that needs the binding means the handle has none: it was never attached, or its own Stop, Kill or Delete removed the binding |
| `PortalError` and subclasses | The project key, attach credentials or Computer registration failed |
| `LifecycleError` and subclasses | A lifecycle call failed (`NotFoundError` confirms the Computer has stopped) |
| `ArtifactNotFoundError` | No file at `path` in the Computer's artifacts (an `ApiError`, status 404) |
| `ArtifactStorageFullError` | The Computer stores more than its limit (`usedBytes`, `limitBytes`); nothing was written |
| `TimeoutError`, `ConnectionError` | No response; the outcome is unknown |

An `AttachCredentialsError` with status 409 and `code`
`urn:pinesandbox:problem:idempotency-receipt-expired` means an attach was sent again
after Portal's receipt for it had expired. Start doesn't send it again and shuts the
new runtime down, so starting again is safe.

`isRetryable(error)` is the server's judgment that repeating the same call is a sane
response. It never makes a mutation safe to send twice: only the SDK's own resends do that. Every call accepts
an `AbortSignal` as `signal`; aborting rejects with the signal's reason, also inside a `for await` over an
event stream.

## Slow or interrupted networks

```ts
import { Agent } from "undici";

const dispatcher = new Agent({ connect: { timeout: 20_000 } });
const client = new Client({
  endpoint: "https://pinesandbox.io",
  apiKey: process.env.PINE_API_KEY!,
  requestTimeoutMs: 60_000,
  fetch: (input, init) => fetch(input, { ...init, dispatcher } as RequestInit),
});
```

`requestTimeoutMs` (default 30 000) bounds a request with no deadline or `signal`
budget of its own; a turn `wait` read gets the time the Computer holds it on top. The
fetch owns its connections, so it sets the connect timeout, which bounds the TCP
connect and the TLS handshake: Node's fetch uses 10 seconds, the other SDKs' default,
and a fetch bound to an undici `Agent`, as above, sets another. Raise them for a slow
or distant network, for example behind a proxy whose TLS handshake takes seconds.

A request whose connection could not be opened never reached Pine, so the SDK sends it
again, three attempts in all, whatever it is. After a fault on an open connection, only
reads, deletes and writes that are safe to repeat are sent again; the others throw
`ConnectionError` or `TimeoutError`. A rejected certificate or a host that doesn't exist
is not special-cased: it goes through the same three attempts and throws
`ConnectionError`.

A `ConnectionError` or `TimeoutError` from `wait`, `events` or another read means this
process lost the network, not that the turn or the Computer failed. The turn keeps
running: wait again, and don't stop the Computer because of it.

## Reporting an issue

```ts
const report = await client.createDiagnostic({ computerId, session: savedSessionName, idempotencyKey });
// Later; poll only queued or running reports, with a deadline:
const latest = await client.getDiagnostic(report.id);
```

The diagnostic investigates the Computer's recorded work and produces a private report
for Pine support and a customer-safe `assessment`. Share its `id` when you ask Pine for
help, with the Computer ID, session name, a UTC time window and any `requestId`.

## Develop

```sh
bun install
bun run generate   # regenerate src/generated from specs/ and the contract
bun run ci         # generate:check, lint, typecheck, unit + contract tests, build, pack:check
bun run e2e        # the shared journeys against a running Pine (see e2e/)
```

`test/contract.test.ts` and `test/scenarios.test.ts` run the language-neutral contract
in `../contract`, which every Pine server SDK passes.
`script/pack-check.ts` installs the packed tarball into a fresh project and loads it
in Node (ESM and CommonJS), Bun, a Cloudflare Worker and a browser bundle.
